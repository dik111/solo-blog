title: 李宏毅机器学习笔记-4 Brief Introduction of Deep Learning；深度学习简介
date: '2018-07-31 06:21:12'
updated: '2018-07-31 06:21:12'
tags: [机器学习]
permalink: /articles/2018/07/31/1573384291889.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

#Three Steps for Deep Learning
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180730/5E3a3iA3ma.png?imageslim)

##Step 1: Neural Network
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180730/h2B725DEj7.png?imageslim)


## 1212

<hr />