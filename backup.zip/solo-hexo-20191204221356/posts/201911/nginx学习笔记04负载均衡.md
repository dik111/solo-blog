title: nginx学习笔记04-负载均衡
date: '2019-11-24 18:45:34'
updated: '2019-11-24 18:48:22'
tags: [nginx]
permalink: /articles/2019/11/24/1574592333970.html
---
![](https://img.hacpai.com/bing/20190430.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 负载均衡

增加服务器的数量，然后将请求分发到各个服务器上，将原先请求集中到单个服务器上的情况改为将请求分发到多个服务器上，将负载分发到不同的服务器，这就是我们所说的负载均衡
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124182442.png)

## nginx负载均衡

### Step0 准备工作

1. 准备2个tomcat，在webapps文件夹下创建edu文件夹,以及在edu/文件夹中创建a.html文件

   ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171215.png)

   ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171248.png)

2. 启动2个tomcat，分别在8080端口以及8081端口

### Step1 修改nginx配置文件

在全局http块中添加以下代码

```shell
 upstream myserver {
        server  192.168.111.100:8080;
        server  192.168.111.100:8081;
    }
```

修改80端口的server块

```shell
 listen       80;
        server_name  192.168.111.100;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html;
            proxy_pass  http://myserver;
            index  index.html index.htm;
        }
```

### Step2 重载nginx配置

```shell
./nginx -s reload
```

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124183735.png)

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124184811.png)

如果访问同一个地址能够出现不同的页面，那就说明配置成功！

## nginx负载均衡分配策略

随着互联网信息的爆炸性增长，负载均衡（load balance）已经不再是一个很陌生的话题，顾名思义，负载均衡即是将负载分摊到不同的服务单元，既保证服务的可用性，又保证响应足够快，给用户很好的体验。快速增长的访问量和数据流量催生了各式各样的负载均衡产品，很多专业的负载均衡硬件提供了很好的功能，但却价格不菲，这使得负载均衡软件大受欢迎，nginx 就是其中的一个，在 linux 下有 Nginx、LVS、Haproxy 等等服务可以提供负载均衡服务，而且 Nginx 提供了几种分配方式(策略)

### 轮询（默认）

每个请求按时间顺序逐一分配到不同的后端服务器，如果后端服务器 down 掉，能自动剔除

### weight

weight 代表权,重默认为 1,**权重越高**被分配的客户端越多

指定轮询几率，weight 和访问比率成正比，用于后端服务器性能不均的情况。 例如：

```shell
 upstream myserver {
        server  192.168.111.100:8080 weight=10;
        server  192.168.111.100:8081 weight=10;
    }
```

### ip_hash

每个请求按访问 ip 的 hash 结果分配，这样每个访客固定访问一个后端服务器，可以解决 session 的问题。 例如：

```shell
upstream myserver {
	   ip_hash;	
        server  192.168.111.100:8080;
        server  192.168.111.100:8081;
    }
```

### fair （第三方）

按后端服务器的响应时间来分配请求，响应时间短的优先分配。

```shell
upstream myserver {
	   	
        server  192.168.111.100:8080;
        server  192.168.111.100:8081;
        fair;
    }
```



