title: 我在 GitHub 上的开源项目
date: '2019-11-10 16:23:08'
updated: '2019-11-10 16:23:08'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/dik111/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/dik111/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.yuweizhan.cn`](http://www.yuweizhan.cn "项目主页")</span>

yuwei的个人博客 - 记录精彩的程序人生



---

### 2. [spring-security-study2](https://github.com/dik111/spring-security-study2) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/dik111/spring-security-study2/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/spring-security-study2/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/spring-security-study2/network/members "分叉数")</span>

spring-security-study2



---

### 3. [springboot-vue-study](https://github.com/dik111/springboot-vue-study) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/dik111/springboot-vue-study/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/springboot-vue-study/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/springboot-vue-study/network/members "分叉数")</span>

springboot-vue-study



---

### 4. [vue-tutorial](https://github.com/dik111/vue-tutorial) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/dik111/vue-tutorial/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/vue-tutorial/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/vue-tutorial/network/members "分叉数")</span>

vue学习



---

### 5. [dik111.github.io](https://github.com/dik111/dik111.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/dik111/dik111.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/dik111.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/dik111.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://dik111.github.io/`](https://dik111.github.io/ "项目主页")</span>

hexo博客



---

### 6. [mkdoc-project](https://github.com/dik111/mkdoc-project) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/dik111/mkdoc-project/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/mkdoc-project/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/mkdoc-project/network/members "分叉数")</span>

mkdoc-project



---

### 7. [Word-frequency-statistics](https://github.com/dik111/Word-frequency-statistics) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/dik111/Word-frequency-statistics/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/dik111/Word-frequency-statistics/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/dik111/Word-frequency-statistics/network/members "分叉数")</span>

Word frequency statistics

