title: Pandas入门简介
date: '2017-10-26 00:15:49'
updated: '2017-10-26 00:15:49'
tags: [python, 数据分析]
permalink: /articles/2017/10/26/1573384289236.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

## Pandas简介
pandas 是基于NumPy 的一种工具，该工具是为了解决数据分析任务而创建的。pandas提供了大量能使我们快速便捷地处理数据的函数和方法。你很快就会发现，它是使Python成为强大而高效的数据分析环境的重要因素之一。
pandas主要使用的是两个数据结构Series和Dataframe,我们先导入它们以及相关模块：

``` python
# -*- coding:utf-8 -*-
import numpy as np
from pandas import Series, DataFrame
```

## Pandas数据结构：Series
一般来说，Series可以被认为是一维数组，Series与一维数组最主要的区别是Series具有索引（index），可以与另一个程序中常见的数据结构联系起来。

### Series的创建
创建Series的基本格式是s = Series(data, index=index, name=name)，下面给出几个创建Series的例子。
``` python
a = np.random.randn(5)
print （"a is an array:"）
print （a）
s = Series(a)
print （"s is a Series:"）
print （s）
```
```
a is an array:
[-1.24962807 -0.85316907  0.13032511 -0.19088881  0.40475505]
s is a Series:
0   -1.249628
1   -0.853169
2    0.130325
3   -0.190889
4    0.404755
dtype: float64
```

在创建Series时可以添加index，而且可以使用Series.index查看具体的index，但是需要注意的一点是，当从数组创建Series时，若指定index，那么index长度要和data的长度一致：
``` python
s = Series(np.random.randn(5), index = ['a' , 'b' , 'c' , 'd' , 'e'])
print(s)
print(s.index)
```
```
a   -0.566972
b   -0.426072
c    0.787193
d    0.526550
e   -1.271557
dtype: float64
Index(['a', 'b', 'c', 'd', 'e'], dtype='object')
```

Series还可以从字典（dict）创建：
```python
d = {'a' : 0. , 'b' : 1. , 'c' : 2}
print("d is a dict:")
print(d)
s = Series(d)
print( "s is a Series:")
print(s)
```
```
d is a dict:
{'a': 0.0, 'b': 1.0, 'c': 2}
s is a Series:
a    0.0
b    1.0
c    2.0
dtype: float64
```


##

<hr />