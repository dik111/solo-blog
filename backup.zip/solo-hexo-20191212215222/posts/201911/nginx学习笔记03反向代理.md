title: nginx学习笔记03-反向代理
date: '2019-11-24 15:17:48'
updated: '2019-11-24 18:03:55'
tags: [nginx]
permalink: /articles/2019/11/24/1574579868131.html
---
![](https://img.hacpai.com/bing/20190906.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# nginx反向代理

反向代理，暴露的是代理服务器地址，隐藏了真实服务器 IP 地址。

![null](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124152448.png)

## 实例1

实现效果：在浏览器输入服务器地址(192.168.111.100)，访问tomcat对应的主页(192.168.111.100:8080)

### Step0 准备工作

1. 在 liunx 系统安装 tomcat ， 使用默认端口 8080

2. 对外开放访问的端口

   firewall-cmd --add-port=8080/tcp --permanent  
   firewall-cmd –reload

3. 查看是否安装成功，在浏览器访问192.168.111.100:8080(地址为你服务器或者虚拟机对应的IP地址)

   ![null](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124153038.png)

### Step1 修改nginx配置文件

vim /usr/local/nginx/conf/nginx.conf

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124154544.png)

### Step2 重载nginx

cd /usr/local/nginx/sbin/  
./nginx -s reload

访问192.168.111.100

![null](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124155035.png)

## 实例2

实现效果:使用 nginx 反向代理，根据访问的路径跳转到不同端口的服务中,nginx 监听端口为 9001

访问 http:// 192.168.111.100:9001/edu/ 直接跳转到 127.0.0.1:8080  访问 http:// 192.168.111.100:9001/vod/ 直接跳转到 127.0.0.1:8081

### Step0 准备工作

1. 准备两个 tomcat 服务器，一个 8080 端口，一个 8081 端口

   具体详细步骤 [https://www.cnblogs.com/chuhongyun/p/11400763.html](https://www.cnblogs.com/chuhongyun/p/11400763.html)

2. 在各自的tomcat/webapps创建用于测试的文件夹以及文件

   #8080 tomcat  
   mkdir edu  
   vim /edu/a.html

   #8081 tomcat文件夹  
   mkdir vod  
   vim /vod/a.html

3. 分别写上不同的内容

   ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171215.png)

   ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171248.png)

### Step1 修改nginx配置文件

在nginx配置文件中，加入以下配置

server {  
 listen       9001;  

 location ~ /edu/ {  
 proxy_pass http://127.0.0.1:8080;  
 }  

 location ~ /vod/ {  
 proxy_pass http://127.0.0.1:8081;  
 }  

 }

### Step2 重载nginx配置，以及开放对应端口

./nginx -s reload

开放对外访问的端口号 9001 8080 8081

### Step3 查看效果

分别访问[http://192.168.111.100:9001/edu/a.html](http://192.168.111.100:9001/edu/a.html)  [http://192.168.111.100:9001/vod/a.html](http://192.168.111.100:9001/vod/a.html)

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171555.png)

![null](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124171607.png)

如果能出现以上的2个页面，那就说明你的配置成功了！

##完整的nginx配置文件

```shell
#user  nobody;
worker_processes  1;

#error_log  logs/error.log;
#error_log  logs/error.log  notice;
#error_log  logs/error.log  info;

#pid        logs/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       mime.types;
    default_type  application/octet-stream;

    #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
    #                  '$status $body_bytes_sent "$http_referer" '
    #                  '"$http_user_agent" "$http_x_forwarded_for"';

    #access_log  logs/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    #keepalive_timeout  0;
    keepalive_timeout  65;

    #gzip  on;

    server {
        listen       80;
        server_name  192.168.111.100;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html;
	    proxy_pass	http://127.0.0.1:8080;
            index  index.html index.htm;
        }

        #error_page  404              /404.html;

        # redirect server error pages to the static page /50x.html
        #
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }

        # proxy the PHP scripts to Apache listening on 127.0.0.1:80
        #
        #location ~ \.php$ {
        #    proxy_pass   http://127.0.0.1;
        #}

        # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
        #
        #location ~ \.php$ {
        #    root           html;
        #    fastcgi_pass   127.0.0.1:9000;
        #    fastcgi_index  index.php;
        #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
        #    include        fastcgi_params;
        #}

        # deny access to .htaccess files, if Apache's document root
        # concurs with nginx's one
        #
        #location ~ /\.ht {
        #    deny  all;
        #}
    }


    # another virtual host using mix of IP-, name-, and port-based configuration
    #
    server {
        listen       9001;

        location ~ /edu/ {
		proxy_pass http://127.0.0.1:8080;
        }

	location ~ /vod/ {
                proxy_pass http://127.0.0.1:8081;
        }

    }


    # HTTPS server
    #
    #server {
    #    listen       443 ssl;
    #    server_name  localhost;

    #    ssl_certificate      cert.pem;
    #    ssl_certificate_key  cert.key;

    #    ssl_session_cache    shared:SSL:1m;
    #    ssl_session_timeout  5m;

    #    ssl_ciphers  HIGH:!aNULL:!MD5;
    #    ssl_prefer_server_ciphers  on;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}

}
```

## location 指令说明

该指令用于匹配 URL

语法如下：

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124180210.png)

1. = ：用于不含正则表达式的 uri 前，要求请求字符串与 uri 严格匹配，如果匹配
   成功，就停止继续向下搜索并立即处理该请求。

2. ~：用于表示 uri 包含正则表达式，并且区分大小写。

3. ~*：用于表示 uri 包含正则表达式，并且不区分大小写。

4. ^~：用于不含正则表达式的 uri 前，要求 Nginx 服务器找到标识 uri 和请求字符串匹配度最高的 location 后，立即使用此 location 处理请求，而不再使用 location块中的正则 uri 和请求字符串做匹配。

   **注意：如果 uri 包含正则表达式，则必须要有 ~ 或者 ~* 标识。**

   
