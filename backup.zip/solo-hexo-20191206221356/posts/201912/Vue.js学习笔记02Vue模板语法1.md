title: Vue.js学习笔记02-Vue模板语法1
date: '2019-12-01 10:26:58'
updated: '2019-12-01 11:52:54'
tags: [Vue, 前端技术, 网站搭建]
permalink: /articles/2019/12/01/1575167218892.html
---
![](https://img.hacpai.com/bing/20190212.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 前言
Vue是一个渐进式框架，它提供了一系列的模板语法用于数据渲染。

# 指令

* 指令就是一个自定义属性
* Vue中指令都是以 v-  开头

## v-cloak

* v-cloak用于防止页面加载时出现闪烁问题

```html
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <title>Document 02</title>
      <style>
          [v-cloak]{
              display: none;
          }
      </style>
  </head>
  <body>
  <div id="app">
      <div v-cloak>{{msg}}</div>
  </div>
  <script type="text/javascript" src="js/vue.js"></script>
  <script type="text/javascript">
      /**
       * v-cloak 指令的用法
       * 1. 提供样式
       * [v-cloak]{
       *     display: none;
       * }
       * 2. 在插值表达式所在的标签中添加v-cloak指令
       *
       * 背后的原理： 先通过样式隐藏内容，然后在内存中进行值的替换，替换好之后
       * 再显示最终的结果
       */
      var vm = new Vue({
          el: '#app',
          data: {
              msg: 'Hello Vue'
          }
      })
  </script>
  </body>
  </html>
  
```

## v-text

* v-text指令用于将数据填充到标签中，作用于插值表达式类似，但是没有闪动问题

* 如果数据中有HTML标签会将html标签一并输出

* 注意：此处为单向绑定，数据对象上的值改变，插值会发生变化；但是当插值发生变化并不会影响数据对象的值

```html
  <div id="app">
      <!--  
		注意:在指令中不要写插值语法  直接写对应的变量名称 
          在 v-text 中 赋值的时候不要在写 插值语法
  		一般属性中不加 {{}}  直接写 对应 的数据名 
  	-->
      <p v-text="msg"></p>
      <p>
          <!-- Vue  中只有在标签的 内容中 才用插值语法 -->
          {{msg}}
      </p>
  </div>
  
  <script>
      new Vue({
          el: '#app',
          data: {
              msg: 'Hello Vue.js'
          }
      });
  
  </script>
```

  

## v-html

* 用法和v-text 相似  但是他可以将HTML片段填充到标签中

* 可能有安全问题, 一般只在可信任内容上使用 `v-html`，**永不**用在用户提交的内容上

* 它与v-text区别在于v-text输出的是纯文本，浏览器不会对其再进行html解析，但v-html会将其当html标签解析后输出。

```html
  <div id="app">
  　　<p v-html="html"></p> <!-- 输出：html标签在渲染的时候被解析 -->
      
      <p>{{message}}</p> <!-- 输出：<span>通过双括号绑定</span> -->
      
  　　<p v-text="text"></p> <!-- 输出：<span>html标签在渲染的时候被源码输出</span> -->
  </div>
  <script>
  　　let app = new Vue({
  　　el: "#app",
  　　data: {
  　　　　message: "<span>通过双括号绑定</span>",
  　　　　html: "<span>html标签在渲染的时候被解析</span>",
  　　　　text: "<span>html标签在渲染的时候被源码输出</span>",
  　　}
   });
  </script>
```

## v-pre

* 显示原始信息跳过编译过程

* 跳过这个元素和它的子元素的编译过程。

* **一些静态的内容不需要编译加这个指令可以加快渲染**

```html
   <span v-pre>{{ this will not be compiled }}</span>    
	<!--  显示的是{{ this will not be compiled }}  -->
	<span v-pre>{{msg}}</span>  
     <!--   即使data里面定义了msg这里仍然是显示的{{msg}}  -->
<script>
    new Vue({
        el: '#app',
        data: {
            msg: 'Hello Vue.js'
        }
    });

</script>
```

## v-once

* 执行一次性的插值【当数据改变时，插值处的内容不会继续更新】

```html
<!-- 即使data里面定义了msg 后期我们修改了 仍然显示的是第一次data里面存储的数据即 Hello Vue.js  -->
     <span v-once>{{ msg}}</span>    
<script>
    new Vue({
        el: '#app',
        data: {
            msg: 'Hello Vue.js'
        }
    });
</script>
```

## 双向数据绑定

* 当数据发生变化的时候，视图也就发生变化
* 当视图发生变化的时候，数据也会跟着同步变化

### v-model

* **v-model**是一个指令，限制在 `<input>、<select>、<textarea>、components`中使用

```html
<div id="app">
      <div>{{msg}}</div>
      <div>
          当输入框中内容改变的时候，  页面上的msg  会自动更新
        <input type="text" v-model='msg'>
      </div>
  </div>
```

## mvvm

* MVC 是后端的分层开发概念； MVVM是前端视图层的概念，主要关注于 视图层分离，也就是说：MVVM把前端的视图层，分为了 三部分 Model, View , VM ViewModel
* m   model
  * 数据层   Vue  中 数据层 都放在 data 里面
* v   view     视图   
  * Vue  中  view      即 我们的HTML页面  
* vm   （view-model）     控制器     将数据和视图层建立联系
  * vm 即  Vue 的实例  就是 vm  

## v-on

* 用来绑定事件的
* 形式如：v-on:click  缩写为 @click;

```html
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <title>Document 06</title>
</head>
<body>
<div id="app">
    <div >{{num}}</div>
    <div>
        <button v-on:click="num++">点击</button>
        <br>
        <button @click="num++">点击1</button>
        <br>
        <button @click=handle()>点击2</button>
    </div>
</div>
<script type="text/javascript" src="js/vue.js"></script>
<script type="text/javascript">
    /**
     *
     */
    var vm = new Vue({
        el: '#app',
        data: {
            num: 0
        },
        methods:{
            handle(){
                this.num++;
            }
        }
    })
</script>
</body>
</html>
```

## v-on事件函数中传入参数

```html
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <title>Document 07</title>
</head>
<body>
<div id="app">
    <div>{{num}}</div>
    <div>
        <br>
        <button @click=handle1>点击1</button>
        <button @click=handle2(123,456,$event)>点击2</button>
    </div>
</div>
<script type="text/javascript" src="js/vue.js"></script>
<script type="text/javascript">
    /**
     *事件绑定-参数传递
     * 1. 如果事件直接绑定函数名称，那么默认会传递事件对象作为事件函数的第一个参数
     * 2. 如果事件绑定函数调用(就是有括号的形式),那么事件对象必须作为最后一个参数
     * 显示传递，并且事件对象的名称必须是$event
     */
    var vm = new Vue({
        el: '#app',
        data: {
            num: 0
        },
        methods: {
            handle2(p, p1, event) {
                console.log(event.target.innerHTML)
                console.log(p)
                this.num++;
            },
            handle1(event) {
                console.log(event.target.innerHTML)
            }
        }
    })
</script>
</body>
</html>
```



## 事件修饰符

* 在事件处理程序中调用 `event.preventDefault()` 或 `event.stopPropagation()` 是非常常见的需求。
* Vue 不推荐我们操作DOM    为了解决这个问题，Vue.js 为 `v-on` 提供了**事件修饰符**
* 修饰符是由点开头的指令后缀来表示的

```html
<!-- 阻止单击事件继续传播 -->
<a v-on:click.stop="doThis"></a>

<!-- 提交事件不再重载页面 -->
<form v-on:submit.prevent="onSubmit"></form>

<!-- 修饰符可以串联   即阻止冒泡也阻止默认事件 -->
<a v-on:click.stop.prevent="doThat"></a>

<!-- 只当在 event.target 是当前元素自身时触发处理函数 -->
<!-- 即事件不是从内部元素触发的 -->
<div v-on:click.self="doThat">...</div>

使用修饰符时，顺序很重要；相应的代码会以同样的顺序产生。因此，用 v-on:click.prevent.self 会阻止所有的点击，而 v-on:click.self.prevent 只会阻止对元素自身的点击。
```

## 按键修饰符

* 在做项目中有时会用到键盘事件，在监听键盘事件时，我们经常需要检查详细的按键。Vue 允许为 `v-on` 在监听键盘事件时添加按键修饰符

```html
<!-- 只有在 `keyCode` 是 13 时调用 `vm.submit()` -->
<input v-on:keyup.13="submit">

<!-- -当点击enter 时调用 `vm.submit()` -->
<input v-on:keyup.enter="submit">

<!--当点击enter或者space时  时调用 `vm.alertMe()`   -->
<input type="text" v-on:keyup.enter.space="alertMe" >

常用的按键修饰符
.enter =>    enter键
.tab => tab键
.delete (捕获“删除”和“退格”按键) =>  删除键
.esc => 取消键
.space =>  空格键
.up =>  上
.down =>  下
.left =>  左
.right =>  右
<script>
	var vm = new Vue({
        el:"#app",
        methods: {
              submit:function(){},
              alertMe:function(){},
        }
    })
</script>
```

## 自定义按键修饰符别名

* 在Vue中可以通过`config.keyCodes`自定义按键修饰符别名

```html
<div id="app">
    预先定义了keycode 116（即F5）的别名为f5，因此在文字输入框中按下F5，会触发prompt方法
    <input type="text" v-on:keydown.f5="prompt()">
</div>

<script>
	
    Vue.config.keyCodes.f5 = 116;

    let app = new Vue({
        el: '#app',
        methods: {
            prompt: function() {
                alert('我是 F5！');
            }
        }
    });
</script>
```


