title: nginx学习笔记01-nginx安装以及常用命令
date: '2019-11-23 22:57:22'
updated: '2019-11-24 11:29:58'
tags: [网站搭建, nginx]
permalink: /articles/2019/11/23/1574521042004.html
---
![](https://img.hacpai.com/bing/20190223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# nginx安装

这次安装nginx采用编译安装的方式，所以在安装nginx之前需要把相关的依赖先安装了

## Step1 安装依赖

### 安装pcre 依赖

1. 第一步联网下载pcre 压缩文件依赖

   ```shell
   wget http://downloads.sourceforge.net/project/pcre/pcre/8.37/pcre-8.37.tar.gz
   ```

2. 第二步解压压缩文件

   ```shell
   tar –xvf pcre-8.37.tar.gz
   ```

3. 执行./configure 

   ```shell
   ./configure 
   ```

4. 编译安装

   ```shell
   make && make install
   ```

5. 最后查看一下是否安装成功

   ```shell
   pre-config --version
   ```

   ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191123231806.png)

### 安装openssl 、zlib 、gcc 依赖

直接用yum安装

```shell
yum -y install make zlib zlib-devel gcc-c++ libtool openssl openssl-deve
```

## Step2 安装与启动nginx

先到官网下载nginx http://nginx.org/

1. 把下载好的nginx进行解压

   ```shell
   tar -zxf nginx-1.12.2.tar.gz
   ```

2.  检查一下相关依赖

   ```shell
   ./configure
   ```

3.  编译安装

   ```shell
   make && make install
   ```

4.  启动nginx

   ```shell
   cd /usr/local/nginx/sbin/
   ./nginx
   ```

5. 开启服务器对应的80远程访问端口

   ```shell
   firewall-cmd --add-port=80/tcp --permanent
   firewall-cmd --reload
   ```

访问对应的地址

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191123233228.png)

如果能出现上面的信息，就表示nginx安装成功了！

# nginx常用命令

- 首先需要进入到nginx的sbin目录

  ```shell
  cd /usr/local/nginx/sbin/
  ```

- nginx启动命令

  ```shell
  ./nginx
  ```

- nginx停止命令

  ```shell
  ./nginx -s stop
  ```

- nginx重新加载配置

  ```shell
  ./nginx -s reload
  ```

- nginx查看版本号

  ```shell
  ./nginx -v
  ```

  ![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124112917.png)









