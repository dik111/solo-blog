title: 大数据入门02-Hadoop伪分布式运行模式
date: '2018-12-18 05:29:27'
updated: '2018-12-18 05:29:27'
tags: [hadoop, 大数据]
permalink: /articles/2018/12/18/1573384292875.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

## 启动HDFS并运行MapReduce程序
###执行步骤
* 配置：hadoop-env.sh
Linux系统中获取JDK的安装路径,并且修改hadoop-env.sh文件中的JAVA_HOME：
```
echo $JAVA_HOME
vim /opt/module/hadoop-2.7.7/etc/hadoop/hadoop-env.sh
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217215536.png)

* 配置：core-site.xml
```
vim /opt/module/hadoop-2.7.7/etc/hadoop/core-site.xml
```
```
<!-- 指定HDFS中NameNode的地址 -->
<property>
<name>fs.defaultFS</name>
    <value>hdfs://hadoop100:9000</value>
</property>

<!-- 指定Hadoop运行时产生文件的存储目录 -->
<property>
	<name>hadoop.tmp.dir</name>
	<value>/opt/module/hadoop-2.7.7/data/tmp</value>
</property>
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217220516.png)
* 配置：hdfs-site.xml
```
vim /opt/module/hadoop-2.7.7/etc/hadoop/hdfs-site.xml
```
```
<!-- 指定HDFS副本的数量 -->
<property>
	<name>dfs.replication</name>
	<value>1</value>
</property>

```

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217220409.png)

这里因为是伪分布式模式，所以副本的数量设置为1。

### 启动集群
* 格式化NameNode（第一次启动时格式化，以后就不要总格式化）

```
cd /opt/module/hadoop-2.7.7/
bin/hdfs namenode -format
```
* 启动NameNode
```
sbin/hadoop-daemon.sh start namenode
```

* 启动DataNode
```
sbin/hadoop-daemon.sh start datanode
```
### 查看集群
* 查看是否启动成功
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217221822.png)

* web端查看HDFS文件系统

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217222111.png)

注意：如果不能查看，看如下帖子处理
http://www.cnblogs.com/zlslch/p/6604189.html

* 查看产生的Log日志
```
cd /opt/module/hadoop-2.7.7/logs/
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181217222402.png)

在企业中遇到Bug时，经常根据日志提示信息去分析问题、解决Bug。

### 操作集群
* 在HDFS文件系统上创建一个input文件夹

```
bin/hdfs dfs -mkdir -p /user/dik/input
```

* 将测试文件内容上传到文件系统上

```
bin/hdfs dfs -put wcinput/wc.input
```

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181223142636.png)

* 运行MapReduce程序

```
bin/hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-2.7.7.jar  wordcount /user/dik/input   /user/dik/output
```

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181223143354.png)



##启动YARN并运行MapReduce程序

### 执行步骤
* 配置yarn-env.sh

配置一下JAVA_HOME

```
echo $JAVA_HOME
vim /opt/module/hadoop-2.7.7/etc/hadoop/hadoop-env.sh
export JAVA_HOME=/opt/module/jdk-11.0.1
```

* 配置yarn-site.xml

```
vim /opt/module/hadoop-2.7.7/etc/hadoop/yarn-site.xml
```

```
<!-- Reducer获取数据的方式 -->
<property>
                <name>yarn.nodemanager.aux-services</name>
                <value>mapreduce_shuffle</value>
</property>

<!-- 指定YARN的ResourceManager的地址 -->
<property>
<name>yarn.resourcemanager.hostname</name>
<value>hadoop101</value>
</property>


<property>
                <name>yarn.nodemanager.aux-services</name>
                <value>mapreduce_shuffle</value>
        </property>

<!-- 日志聚集功能使能 -->
        <property>

                <name>yarn.log-aggregation-enable</name>
                <value>true</value>
        </property>
        <property>
                <name>yarn.log-aggregation.retain-seconds</name>
                <value>604800</value>
        </property>
```

* 配置：mapred-env.sh


配置一下JAVA_HOME

```
vim /opt/module/hadoop-2.7.7/etc/hadoop/mapred-env.sh
export JAVA_HOME=/opt/module/jdk-11.0.1
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181223145451.png)

* 配置： (对mapred-site.xml.template重新命名为) mapred-site.xml

```
mv mapred-site.xml.template mapred-site.xml
vim /opt/module/hadoop-2.7.7/etc/hadoop/
```

```
<!-- 指定MR运行在YARN上 -->
<property>
                <name>mapreduce.framework.name</name>
                <value>yarn</value>
</property>

<!-- 历史服务器端地址 -->
<property>
<name>mapreduce.jobhistory.address</name>
<value>hadoop101:10020</value>
</property>
<!-- 历史服务器web端地址 -->
<property>
    <name>mapreduce.jobhistory.webapp.address</name>
    <value>hadoop101:19888</value>
</property>

```
### 启动集群
启动前必须保证NameNode和DataNode已经启动

* 启动ResourceManager

```
sbin/yarn-daemon.sh start resourcemanager
```

* 启动NodeManager

```
sbin/yarn-daemon.sh start nodemanager
```

### 集群操作

* YARN的浏览器页面查看

http://hadoop101:8088/cluster

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181223150126.png)

* 删除文件系统上的output文件

```
bin/hdfs dfs -rm -R /user/dik/outpu
```

* 执行MapReduce程序

```
bin/hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-2.7.7.jar  wordcount /user/dik/input /user/dik/output
```

到这里一个简单的伪分布式运行模式就搭建成功啦！


<hr />