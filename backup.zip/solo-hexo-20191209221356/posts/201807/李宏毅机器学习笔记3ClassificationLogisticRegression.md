title: 李宏毅机器学习笔记-3 Classification,Logistic Regression
date: '2018-07-27 06:23:06'
updated: '2018-07-27 06:23:06'
tags: [机器学习]
permalink: /articles/2018/07/27/1573384296771.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

# Classification
分类算法在我们日常生活中随处可见：
* Credit Scoring
Input: income, savings, profession, age, past financial history ……
Output: accept or refuse
* Medical Diagnosis
Input: current symptoms, age, gender, past medical history ……
Output: which kind of diseases
* Handwritten character recognition
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/AkGlIbdGgc.png?imageslim)
* Face recognition
Input: image of a face
output: person

##Example Application
在这节课程中，李宏毅老师通过宝可梦的HP值，Attack值，SP Atk值，SP Def值，Speed值等一系列值来预测宝可梦属于哪种类型。
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/8099K1GAfJ.png?imageslim)

##How to do Classification?
* Traning data for Classification
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/c26cgkJhEK.png?imageslim)

###Classification as Regression?
Binary classification as example
Training: Class 1 means the target is 1; Class 2 means the target is -1
Testing: closer to 1 → class 1; closer to -1 → class 2 

##Ideal Alternatives(理想的替代品)
* Function (Model):
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/egL5b6jCl3.png?imageslim)
* Loss function:
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/f61LhjE1D9.png?imageslim)
* Find the best funcion:
Example:Perceptron , SVM
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/ldDGiKk3Ei.png?imageslim)
在这里我们用线性回归算法进行分类，我们把接近-1的数据定义为class2,把接近1的数据定义为class1，以此作为分类，可以看到当数据远大于1时，绿色的直线慢慢往紫色的直线靠近了，因此在某种情况下，用线性回归进行分类可能会不太准确。
##Naive Bayes
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/cAl19gA77A.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/690BGedG7C.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/dmikm1mgLD.png?imageslim)
其中 **mean μ** 和 **covariance matrix ∑** 是决定形状的两个因素，而不同的参数，会有不同的形状：
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180728/dj87mK6dmc.png?imageslim)

##Probability from Class
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/h0m7DD8CmL.png?imageslim)
###那如何找到这个Gaussion function呢？
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/jD3Eg7eici.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/L1cLAB0cDK.png?imageslim)
##Summery
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/DF3L2L9aFA.png?imageslim)
##Probability Distribution
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/2FHlmfB0FI.png?imageslim)

#Logistic Regression
##The steps of Logistic Regression
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/C3kCa0d4Cd.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/a7F5I1i9FJ.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/9A96DEL9IL.png?imageslim)
##Logistic Regression VS Linear Regression
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/cB393jDfIJ.png?imageslim)
##为什么不能用Logistic Regression+Square Error
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/f9kHgKj4Bd.png?imageslim)
##Cross Entropy v.s. Square Error
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/B8aFe713FJ.png?imageslim)
##Discriminative（Logstic） v.s. Generative（Gaussion）
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/BjFceKIEFF.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/bkh0iBek86.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/GGegFb7ECH.png?imageslim)

##Multi-class Classification
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/74i9FEki8K.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/KHa7mdjfg4.png?imageslim)
##Limitation of Logistic Regression
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/2C76EfHHIk.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/AadIi6ge6E.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/7bB6beKdgH.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/181m216d0J.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/1I8ACL4525.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180729/bF173Hj86c.png?imageslim)
<hr />