title: django入门-搭建字数统计网站
date: '2018-09-02 06:52:05'
updated: '2018-09-02 06:52:05'
tags: [django, 网站搭建]
permalink: /articles/2018/09/02/1573384289968.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />
最近工作需要在数据分析系统中增加一些机器学习有关的工具，因为部门里面有些人不会python,为了方便大家使用，所以用django搭建一个网站。
<!-- more -->

##安装django

```python
pip install django
```

##新建项目

```python
django-admin startproject wordcount2
```
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/0B9d0edHHL.png?imageslim)

##启动本地服务器
进入新建的项目文件夹

```python
python manage.py runserver
```
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/1DBC7LcK1J.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/2fF6g5mimC.png?imageslim)
如果你看到这个页面，就表示你的django安装成功啦！

##新建主页
* 在wordcount2文件夹中新建templates文件夹，用于存放html文件
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/BDF4550hfh.png?imageslim)

* 在templates文件夹中新建home.html文件
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/kKGJEDL16j.png?imageslim)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>字数统计</title>
</head>
<body>
<h1>字数统计</h1>
    <form >
        <textarea cols="100" rows="25" name="text">在此输入文本</textarea>
        <br>
        <input type="submit" value="统计">
    </form>
    <a href="about">关于本页</a>
</body>
</html>
```

* 配置settings.py文件
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/k8Ic1F6kBA.png?imageslim)

在这里我们需要配置settings.py文件，用来告诉django，我们的html文件在哪。

* 新增function.py文件

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/K1H2KJChIF.png?imageslim)

在wordcount2文件夹中新增function.py文件，并且新增home函数。

```python
def home(request):
    return  render(request,'home.html')
```
### render函数：
```python
request: 是一个固定参数, 没什么好讲的。

template_name: templates 中定义的文件, 要注意路径名. 比如'templates\polls\index.html', 参数就要写‘polls\index.html’

context: 要传入文件中用于渲染呈现的数据, 默认是字典格式

content_type: 生成的文档要使用的MIME 类型。默认为DEFAULT_CONTENT_TYPE 设置的值。

status: http的响应代码,默认是200.

using: 用于加载模板使用的模板引擎的名称。
```

* 配置在urls.py文件
  
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/ca2i3H6Kfs总结.png?imageslim)
在urls.py文件中，需要我们配置网站地址以及映射的函数。

在这里首页已经配置完成啦！
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/CbI35ciFmi.png?imageslim)

##增加统计结果网页
当用户把需要统计的文字填入文字框中，并且按统计按钮之后，我们的页面需要跳转到统计结果的页面中。

* 配置home.html文件
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>字数统计</title>
</head>
<body>
<h1>字数统计</h1>
    <form action="count">
        <textarea cols="100" rows="25" name="text">在此输入文本</textarea>
        <br>
        <input type="submit" value="统计">
    </form>
    <a href="about">关于本页</a>
</body>
</html>
```
在form标签中添加action="count"

* 增加count.html文件
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>统计结果</title>
</head>
<body>
<h1>统计结果，总字数为{{count}}字</h1>
<h2>你的文本</h2>
{{text}}
</body>
</html>
```

* 配置urls.py文件

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/lb0k2d8dHi.png?imageslim)

* 在function中新增count函数
```python
def count(request):
    user_text = request.GET['text'] ##获取用户输入的文字
    total_count = len(user_text)  ##统计字数
    return render(request,'count.html',{'count':total_count,'text':user_text})
```

在这里需要注意的是我们通过render函数向html传递参数的时候需要以字典的形式传递。
**{'count':total_count,'text':user_text}**

如果没有出错的话，当你点击统计之后会跳转到这个页面
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/lD873LF5H4.png?imageslim)

### 字数统计

完整的count函数代码

```python

def count(request):
    user_text = request.GET['text']
    user_text1 = request.GET['text']
    user_text = re.findall('[\u4e00-\u9fa5]', user_text, re.S) ##用正则表达式去掉符号以及数字
    total_count=len(user_text)

    word_dict = {}
    for word in user_text:
        if word not in word_dict:
            word_dict[word] = 1

        else:
            word_dict[word] += 1

    dataframe = pd.DataFrame(list(word_dict.keys()), columns=['字'])
    dataframe['频次'] = pd.DataFrame(list(word_dict.values()))
    dataframe.sort_values('频次', inplace=True, ascending=False)
    old_width = pd.get_option('display.max_colwidth') ##因为dataframe太长的话会显示不全，所以需要新增以下代码
    pd.set_option('display.max_colwidth', -1)
    dataframe = dataframe.to_html(escape=False, index=False, sparsify=True, border=0, index_names=False, header=False)
    pd.set_option('display.max_colwidth', old_width)

    return render(request , 'count.html',{'count':total_count , 'text':user_text1,'dict':dataframe})
```

上面的代码就是把用户输入的文字通过循环的方式统计字数，然后把字典转换成dataframe,传递给html。

* 完整的count.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>统计结果</title>
</head>
<body>
<h1>统计结果，总字数为{{count}}字</h1>
<h2>你的文本</h2>
{{text}}
<br>
{% autoescape off %}
{{dict}}
{% endautoescape %}
<a href="..">回到主页</a>
</body>
</html>
```

### 关于django自动转义

Django的模板中会对HTML标签和JS等语法标签进行自动转义，原因显而易见，这样是为了安全。但是有的时候我们可能不希望这些HTML元素被转义，比如我们做一个内容管理系统，后台添加的文章中是经过修饰的，这些修饰可能是通过一个类似于FCKeditor编辑加注了HTML修饰符的文本，如果自动转义的话显示的就是保护HTML标签的源文件。为了在Django中关闭HTML的自动转义有两种方式，如果是一个单独的变量我们可以通过过滤器“|safe”的方式告诉Django这段代码是安全的不必转义。比如：

```

<p>这行代表会被自动转义</p>: {{ data }}
<p>这行代表不会被自动转义</p>: {{ data|safe }}

```

其中第二行我们关闭了Django的自动转义。
我们还可以通过
```
{%autoescape off%}
```
的方式关闭整段代码的自动转义，比如下面这样：

```

{% autoescape off %}
    Hello {{ name }}
{% endautoescape %}

```

##增加about页面

我们需要新增一个about页面用于告诉用户，我们这个页面是用来干什么的,步骤与之前的都差不多。

* 增加about.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>关于本页</title>
</head>
<body>
<h1>关于本页</h1>
<h2>本网站可以统计字数，并且会按频次降序排列</h2>
<a href="..">回到主页</a>
</body>
</html>
```

* 配置urls.py文件
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/mEG20dic17.png?imageslim) 

* 配置function文件，新增about函数
  
```python
def about(request):
    return render(request ,'about.html')
```

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180902/FdjaaGjf1L.png?imageslim)

在这里一个简单的字数统计网站就搭建好啦！
完整项目代码:https://github.com/dik111/word_count


<hr />