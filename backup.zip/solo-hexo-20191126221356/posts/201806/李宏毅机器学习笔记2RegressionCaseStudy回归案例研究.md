title: 李宏毅机器学习笔记-2 （Regression：Case Study ；回归：案例研究）
date: '2018-06-27 06:36:43'
updated: '2018-06-27 06:36:43'
tags: [机器学习]
permalink: /articles/2018/06/27/1573384297509.html
---
<p class="description"></p>



<!-- more -->

## Regression-pokemons
李老师在这一节课程开始介绍了用Regression，预测预测宝可梦（ 
pokemons）进化后过的CP值（战斗力）。
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180626/DbEKa15F6H.png?imageslim)
我们的目标是找出上帝函数'f',通过imput一只宝可梦进化前的cp值，output他进化后的cp值。

## Step1 选择Model
在这里李老师建立以个Linear model:
 ```python
 y = b + w * x
它是infinite的……
可能为f1: y = 10.0 + 9.0 ∙ x
可能为f2: y = 9.8 + 9.2 ∙ x
可能为f3: y = - 0.8 - 1.2 ∙ x
……  
  ```
不同的b和w都会得到不同的f，而我们的目标就是找出一个最合适的f。
## Step2 Goodness of function
当我们将准备好的training data（已知10个宝可梦的进化情况），建立一个二维坐标轴。
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/ag4Ch54Im0.png?imageslim)

通过上图可以看出，似乎有一个函数能够拟合这些坐标点，而这就是我们想要的，为了选出最契合的 f ，我们要建立一个Loss function L ，也就是函数的函数。
* 如果我们将 f 的 w 和 b 作为两轴，则在下图中每一点都代表一个 function f ，而颜色代表output的大小，也就代表该function f 参数的好坏。易理解，smallest点做对应的函数 f 就是我们想要的。

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/f9FiG60Ab3.png?imageslim)

## Step3 Best Function
在lossfuction建立之后，我们需要通过这些这些lossfuction找到最合适的Best fuction,在这里，我们通过线性代数的基本公式来直接计算出最佳的w和b。

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/BhlKFH27KE.png?imageslim)
这种方法适用于单一特征的问题，但现实中，我们的问题往往是涉及到多个特征的，这时，则需要我们用更有效fuction,这里，李老师介绍了梯度下降法进行计算。
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/j68LdEI3dI.png?imageslim)
首先我们需要随机选取一个w0,计算其斜率，如果为正，则减小w，如果为负，则增大w。而这有另一个问题，每次要增加或减少多少w值呢，有两个因素影响。第一，即微分值，如果微分值很大或很小，表示此处非常陡峭，那么证明距离最低点还有很远的距离，所以移动的距离就很大。第二个因素是我们事先自主定义的常数项 η 值，即步长。
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/c0fikGF2DA.png?imageslim)

经过无数次迭代之后，参数会经过无数次更新，最终到达一个最低值。而当我们有多个feature时，即不仅有w和b时，同样不会影响梯度下降过程，其原理为：

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/i3eBFegkbg.png?imageslim)

## How’s the results?
经过上面的步骤后，我们得到了一个函数f，但我们发现并不是所有数据都能很好的拟合函数，这就会造成很大的预测不准的情况，通过Loss Function也能看出，最优解的值依然很大，测试数据的表现也不好，所以我们就要想办法优化。

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/9IKDCEfK56.png?imageslim)

很容易想到，刚刚我们用了一次方程作为model，二次方程会不会更好一些呢，三次方程、四次方程呢？于是我们做了以下实验，用同样的方法，放到多次方程中。

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/L4Gh3cgfm7.png?imageslim)
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/Ae4g6bEfKK.png?imageslim)

## overfitting
从上面的4幅图可以看出，虽然我们增加了函数次数后，可以使得training set 的error越来越小，但是test set的error并没有随着次数的增大而减小，甚至到5次时，结果大大超出了我们的预估，那么这种现象就叫做overfitting。

![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/C7C7Ad87eD.png?imageslim)

由此可见，fuction并不是越复杂越好，我们需要根据实际情况来选择合适的fuction，而对于overfitting的应对办法，我们一般采用以下方法来解决：
* 增加新特征，可以考虑加入进特征组合、高次特征，来增大假设空间;
* 尝试非线性模型，比如核SVM 、决策树、DNN等模型;
* 如果有正则项可以较小正则项参数 λ
* Boosting ,Boosting 往往会有较小的 Bias，比如 Gradient Boosting 等.

## underfitting
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/DHJj85dL4K.png?imageslim)
有过拟合当然也少不了欠拟合了，对于欠拟合,我们一般采用以下方法解决：
* 增加新特征，可以考虑加入进特征组合、高次特征，来增大假设空间;
* 尝试非线性模型，比如核SVM 、决策树、DNN等模型;
* 如果有正则项可以较小正则项参数 λ.
* Boosting ,Boosting 往往会有较小的 Bias，比如 Gradient Boosting 等.

## 交叉检验
当数据比较少是，留出一部分做交叉检验可能比较奢侈，还有只执行一次训练-测试来评估模型，会带有一些随机性，这些缺点都可以通过交叉检验克服，交叉检验对数据的划分如下：
![mark](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/blog/180627/Cc02gFb7aE.png?imageslim)
### 交叉检验的步骤：
1. 将数据分类训练集、验证集、测试集；
2. 选择模型和训练参数；
3. 使用训练集训练模型，在验证集中评估模型；
4. 针对不同的模型，重复2）- 3）的过程；
5. 选择最佳模型，使用训练集和验证集一起训练模型；
6. 使用测试集来最终测评模型。

## 关于正则
在模型的损失函数中引入正则项，可用来防止过拟合，于是得到的优化形式如下：

$$
w^*=argminwL(y,f(w,x))+λΩ(w)
$$
这里 Ω(w) 即为正则项， λ  则为正则项的参数，通常为 Lp 的形式，即：
$$Ω(w)=||w||^p$$
实际应用中比较多的是 L1 与 L2 正则，L1 正则是 L0 正则的凸近似，这里 L0 正则即为权重参数 w 中值为 0 的个数，但是求解 L0 正则是个NP 难题，所以往往使用 L1 正则来近似 L0 , 来使得某些特征权重为 0 ，这样便得到了稀疏的的权重参数 w。

在下一篇的文章我会结合李宏毅老师的课后作业，用python实现梯度下降算法，敬请期待！

相关参考：
https://blog.csdn.net/soulmeetliang/article/details/72619885
https://www.cnblogs.com/ooon/p/5715918.html


<hr />