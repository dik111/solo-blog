title: 大数据入门04-pyspark环境搭建
date: '2018-12-20 05:38:55'
updated: '2018-12-20 05:38:55'
tags: [pyspark, 大数据]
permalink: /articles/2018/12/20/1573384296430.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

##安装Spark依赖的Scala
Hadoop的安装请参考上面提到的博文，因为Spark依赖scala，所以在安装Spark之前，这里要先安装scala。在每个节点上都进行安装。

### 下载和解压缩Scala
打开地址：https://www.scala-lang.org/download/

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131141743.png)

### 配置scala环境变量
* 打开配置文件
```
vim /etc/profile
```
```
export SCALA_HOME=/root/module/scala-2.12.8
export PATH=$PATH:$SCALA_HOME/bin
```
* 保存之后刷新配置文件
```
source /etc/profile
```
* 验证是否配置好
```
scala -version
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131142644.png)

## 下载和解压缩Spark
打开下载地址：
http://spark.apache.org/downloads.html

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131142831.png)

选择清华源

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131142859.png)

###  配置spark环境变量
* 编辑/etc/profile文件，添加

```
export SPARK_HOME=/root/module/spark-2.3.2-bin-hadoop2.7
export PATH=$PATH:$SPARK_HOME/bin
export PYSPARK_PYTHON=/home/dik/anaconda3/bin/python3.7
```

### 配置conf目录下的文件
/root/module/spark-2.3.2-bin-hadoop2.7/conf目录下的文件进行配置

* 新建spark-env.h文件
以spark为我们创建好的模板创建一个spark-env.h文件，命令是：
```
cp    spark-env.sh.template   spark-env.sh
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131143625.png)

* 编辑spark-env.h文件，在里面加入配置(具体路径以自己的为准)：

```
export SCALA_HOME=/root/module/scala-2.12.8
export JAVA_HOME=/root/module/jdk1.8.0_191
export HADOOP_HOME=/root/module/hadoop-2.7.7
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export SPARK_HOME=/root/module/spark-2.3.2-bin-hadoop2.7
```

### 新建slaves文件
/root/module/spark-2.3.2-bin-hadoop2.7/conf目录下的文件进行配置

以spark为我们创建好的模板创建一个slaves文件，命令是：
```
cp    slaves.template   slaves
```
编辑slaves文件，里面的内容为：
```
spark001
```

## 启动和测试Spark集群
###启动Spark
* 切换到sbin目录
```
cd /root/module/spark-2.3.2-bin-hadoop2.7/sbin
```
* 执行启动脚本：
```
./start-all.sh
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131145420.png)
* 查看是否启动
```
jps
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131145519.png)

### 测试和使用Spark集群
* 访问Spark集群提供的URL
http://spark001:8080/
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131145627.png)

* 运行Spark提供的计算圆周率的示例程序
进入到Spark的根目录
```
cd ..
```
调用Spark自带的计算圆周率的Demo，执行下面的命令：

```
./bin/spark-submit --class org.apache.spark.examples.SparkPi --master local examples/jars/spark-examples_2.11-2.3.2.jar
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131150149.png)

## 配置pyspark远程调试环境
###安装Anaconda3 
因为服务器自带的python版本是python2的，所以要安装python3,而Anaconda3是一个比较好的选择。

* 下载地址：
https://repo.continuum.io/archive/Anaconda3-5.1.0-Linux-x86_64.sh

* 依赖安装bzip2： yum -y install bzip2
* 安装anaconda3
```
bash Anaconda3-5.0.1-Linux-x86_64.sh
```
安装的过程比较简单，这里就不复述了。
安装完成之后修改配置文件 ~/.bashrc
进入添加至最后一行
export PATH="/root/anaconda3/bin:$PATH" 
这里需注意,一定要加双引号,否则会因此没有反应
```
 source ~/.bashrc
 ```
### 配置本地pycharm环境
* 安装py4j

```
pip install py4j
```
* 配置pycharm 远程

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131153852.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131153930.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131153955.png)

* 配置远程的编译器

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131154157.png)

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131154416.png)

* 新建一个pyspark项目
填入以下测试代码
``` python
# -*- coding: UTF-8 -*-
from pyspark import SparkConf, SparkContext


def my_map():
    """
    map(func)
	将func函数作用到数据集的每一个元素上，生成一个新的分布式的数据集返回

	word => (word,1)
    :return:
    """
    data = [1, 2, 3, 4, 5]
    rdd1 = sc.parallelize(data)
    rdd2 = rdd1.map(lambda x: x * 2)
    print(rdd2.collect())
if __name__ == '__main__':
    conf = SparkConf().setAppName('local[2]')
    sc = SparkContext(conf=conf)

    my_map()

    sc.stop()

```
* 配置
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131154635.png)

在里面加入对应的JAVA_HOME,PYTHONPATH,SPARK_HOME
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131154819.png)
* 运行代码
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190131154928.png)
如果没报错的话，那么就搭建成功了！
<hr />