title: nginx学习笔记02-nginx配置文件
date: '2019-11-24 13:02:00'
updated: '2019-11-24 17:53:41'
tags: [nginx]
permalink: /articles/2019/11/24/1574571720335.html
---
![](https://img.hacpai.com/bing/20180826.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## nginx配置文件概述

nginx的配置文件主要是由三部分组成:`全局块` `events 块`  `http 块`

### 全局块

从配置文件开始到 events 块之间的内容，主要会设置一些影响 nginx 服务器整体运行的配置指令，主要包括配置运行 Nginx 服务器的用户（组）、允许生成的 worker process 数，进程 PID 存放路径、日志存放路径和类型以
及配置文件的引入等。

比如 worker_processes 1; 处理并发数的配置

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124132048.png)

这是 Nginx 服务器并发处理服务的关键配置，worker_processes 值越大，可以支持的并发处理量也越多，但是会受到硬件、软件等设备的制约

### events 块 


比如 worker_connections 1024; 支持的最大连接数为 1024

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124132338.png)

events 块涉及的指令主要影响 Nginx 服务器与用户的网络连接，常用的设置包括是否开启对多 work process下的网络连接进行序列化，是否允许同时接收多个网络连接，选取哪种事件驱动模型来处理连接请求，每个 word process 可以同时支持的最大连接数等。

### http 块

这算是 Nginx 服务器配置中最频繁的部分，代理、缓存和日志定义等绝大多数功能和第三方模块的配置都在这里。需要注意的是：http 块也可以包括 http 全局块、server 块。

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20191124133344.png)

1.  http块
http 全局块配置的指令包括文件引入、MIME-TYPE 定义、日志自定义、连接超时时间、单链接请求数上限等。

2. server 块
**一个 server 块可以配置多个 location 块。**
这块的主要作用是基于 Nginx 服务器接收到的请求字符串（例如 server_name/uri-string），对虚拟主机名称（也可以是 IP 别名）之外的字符串（例如 前面的 /uri-string）进行匹配，对特定的请求进行处理。地址定向、数据缓存和应答控制等功能，还有许多第三方模块的配置也在这里进行。





