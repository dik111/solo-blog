title: 大数据入门01-Hadoop运行环境搭建
date: '2018-12-09 20:35:44'
updated: '2018-12-09 20:35:44'
tags: [hadoop, 大数据]
permalink: /articles/2018/12/09/1573384293676.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />
这篇文章主要介绍的是Hadoop运行环境搭建
<!-- more -->

## 虚拟机环境准备
###	克隆虚拟机
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209151821.png)

###	修改克隆虚拟机的静态IP
进入 /etc/sysconfig/network-scripts中
``` linux
cd /etc/sysconfig/network-scripts
vim ifcfg-eth0 
```
需要对这几项进行修改：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209152921.png)


### 修改主机名
```
cd /etc/sysconfig
sudo vim network
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209153740.png)

### 配置hosts文件
* 打开hosts文件
```
cd /etc/hosts
```
* 配置
```
192.168.111.100 hadoop100
192.168.111.101 hadoop101
192.168.111.102 hadoop102
192.168.111.103 hadoop103
192.168.111.104 hadoop104
192.168.111.105 hadoop105
192.168.111.106 hadoop106
```

### 关闭防火墙
```
systemctl stop firewalld.service 
```

禁止防火墙开机启动
```
systemctl disable firewalld.service
```
### 在/opt目录下创建文件夹

* 在/opt目录下创建module、software文件夹,其中software文件夹用于软件包的存储，module文件夹用于软件的安装
```
sudo mkdir module
sudo mkdir software
```

* 修改module、software文件夹的所有者
```
sudo chown dik:dik module/ software/
```

## 安装JDK以及配置环境变量

###卸载现有JDK
* 查询是否安装Java软件：
```
rpm -qa | grep java
```
* 用Xshell工具将JDK导入到opt目录下面的software文件夹下面

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209174120.png)

* 在Linux系统下的opt目录中查看软件包是否导入成功

### 解压JDK到/opt/module目录下
```
tar -zxvf jdk-11.0.1_linux-x64_bin.tar.gz -C /opt/module/
```
### 配置JDK环境变量
* 先获取JDK路径
```
[dik@hadoop102 jdk-11.0.1]$ pwd
/opt/module/jdk-11.0.1
```
* 打开/etc/profile文件
```
sudo vim /etc/profile
```
* 在profile文件末尾添加JDK路径
```
export JAVA_HOME=/opt/module/jdk-11.0.1
export PATH=$PATH:$JAVA_HOME/bin
```

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209174802.png)

* 让修改后的文件生效
```
source /etc/profile
```
* 测试JDK是否安装成功
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209174957.png)

## 安装Hadoop以及配置环境变量
Hadoop下载地址：
https://archive.apache.org/dist/hadoop/common/hadoop-2.7.7/
也可以在官网直接下载。

### 导入Hadoop软件包
用Xshell工具将hadoop-2.7.7.tar.gz导入到opt目录下面的software文件夹下面

### 安装Hadoop
* 进入到Hadoop安装包路径下
```
cd /opt/software/
```
* 解压安装文件到/opt/module下面
```
tar -zxvf hadoop-2.7.7.tar.gz -C /opt/module/
```

### 将Hadoop添加到环境变量
* 获取Hadoop安装路径
```
[dik@hadoop102 module]$ cd hadoop-2.7.7/
[dik@hadoop102 hadoop-2.7.7]$ pwd
/opt/module/hadoop-2.7.7
```
* 打开/etc/profile文件,在profile文件末尾添加hadoop路径
```
##HADOOP_HOME
export HADOOP_HOME=/opt/module/hadoop-2.7.7
export PATH=$PATH:$HADOOP_HOME/bin
export PATH=$PATH:$HADOOP_HOME/sbin
```
* 让修改后的文件生效
```
source /etc/profile
```
* 测试是否安装成功
```
[dik@hadoop102 hadoop-2.7.7]$ hadoop version
Hadoop 2.7.7
Subversion Unknown -r c1aad84bd27cd79c3d1a7dd58202a8c3ee1ed3ac
Compiled by stevel on 2018-07-18T22:47Z
Compiled with protoc 2.5.0
From source with checksum 792e15d20b12c74bd6f19a1fb886490
This command was run using /opt/module/hadoop-2.7.7/share/hadoop/common/hadoop-common-2.7.7.jar
```
## Hadoop目录结构
```
[dik@hadoop102 hadoop-2.7.7]$ ll
total 116
drwxr-xr-x. 2 dik dik   194 Dec  6 23:56 bin
drwxrwxr-x. 3 dik dik    17 Dec  7 22:50 data
drwxr-xr-x. 3 dik dik    20 Dec  6 23:56 etc
drwxr-xr-x. 2 dik dik   106 Dec  6 23:56 include
drwxrwxr-x. 2 dik dik   187 Dec  6 23:58 input
drwxr-xr-x. 3 dik dik    20 Dec  6 23:56 lib
drwxr-xr-x. 2 dik dik   239 Dec  6 23:56 libexec
-rw-r--r--. 1 dik dik 86424 Dec  6 23:56 LICENSE.txt
drwxrwxr-x. 3 dik dik  4096 Dec  9 09:40 logs
-rw-r--r--. 1 dik dik 14978 Dec  6 23:56 NOTICE.txt
drwxrwxr-x. 2 dik dik    88 Dec  6 23:58 output
-rw-r--r--. 1 dik dik  1366 Dec  6 23:56 README.txt
drwxr-xr-x. 2 dik dik  4096 Dec  8 00:37 sbin
drwxr-xr-x. 4 dik dik    31 Dec  6 23:57 share
```
### 重要目录
（1）bin目录：存放对Hadoop相关服务（HDFS,YARN）进行操作的脚本
（2）etc目录：Hadoop的配置文件目录，存放Hadoop的配置文件
（3）lib目录：存放Hadoop的本地库（对数据进行压缩解压缩功能）
（4）sbin目录：存放启动或停止Hadoop相关服务的脚本
（5）share目录：存放Hadoop的依赖jar包、文档、和官方案例



## 本地模式运行Hadoop
### 官方Grep案例
* 创建在hadoop-2.7.7文件下面创建一个input文件夹
```
mkdir input
```
* 将Hadoop的xml配置文件复制到input
```
cp etc/hadoop/*.xml input
```
* 执行share目录下的MapReduce程序
```
bin/hadoop jar  share/hadoop/mapreduce/hadoop-mapreduce-examples-2.7.7.jar grep input output 'dfs[a-z.]+'
```
* 查看输出结果
```
cat output/*
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20181209185510.png)


到这里一个简单的Hadoop运行环境就搭建成功了！
<hr />