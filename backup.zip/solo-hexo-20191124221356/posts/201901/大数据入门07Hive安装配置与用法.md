title: 大数据入门07-Hive安装配置与用法
date: '2019-01-03 06:00:04'
updated: '2019-01-03 06:00:04'
tags: [Hive, 大数据]
permalink: /articles/2019/01/03/1573384297004.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />
在这篇文章中，我们会安装配置Hive,并且把Hive的元数据库配置在mysql上面。
<!-- more -->

##Hive安装配置
下载地址:https://mirrors.tuna.tsinghua.edu.cn/apache/hive/
### 下载&安装
```
wget https://mirrors.tuna.tsinghua.edu.cn/apache/hive/hive-2.3.4/apache-hive-2.3.4-bin.tar.gz
```
解压到/opt/module/目录
```
tar -zxvf tar -zxvf apache-hive-2.3.4-bin.tar.gz  -C ../module/hive-2.3.4
```
### 配置环境变量
```
vim /etc/profile
```
插入以下内容
```
##HIVE_HOME
export HIVE_HOME=/opt/module/hive-2.3.4
export PATH=$PATH:$HIVE_HOME/bin
```
刷新环境
```
source /etc/profile
```

### 配置Hive
切换到Hive/conf目录中
```
cp hive-env.sh.template hive-env.sh
```
在hive-env.sh文件中添加hadoop路径以及hive的conf路径
```
HADOOP_HOME=/opt/module/hadoop-2.7.7
export HIVE_CONF_DIR=/opt/module/hive-2.3.4
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302224327.png)

##安装MySQL数据库
hive默认自带的derby数据库，但是在这种模式下，hive只能打开一个。所以我们把hive的元数据库搭建在MySQL上面
### 下载安装
* 下载地址：https://dev.mysql.com/downloads/mysql/5.7.html#downloads
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302224741.png)
* 首先卸载操作系统可能会自带的mariadb-libs
```
yum -y remove mariadb-libs
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302224842.png)

解压mysql rpm-bundle tar包
```
mkdir mysql
tar -xvf mysql-5.7.25-1.el7.x86_64.rpm-bundle.tar -C mysql
```
* 开始安装mysq
一定要按照下面的顺序来安装，否则会安装不成功：
```
rpm -ivh mysql-community-common-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-client-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-server-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-compat-5.7.25-1.el7.x86_64.rpm
```
### 配置
* 启动mysql服务,并且设置为开机启动
```
systemctl start mysqld
systemctl enable mysqld
```
* 查看root用户初始密码,并且登录MySQL
```
grep password /var/log/mysqld.log
mysql -uroot -p
```
* 修改MySQL的密码长度以及安全性要求
因为MySQL有长度以及安全性的要求，所以需要对此作出修改
```
set global validate_password_policy=0; 
set global validate_password_length=1;
```
* 修改root密码
```
set password = password('123456');
```
* 设置远程登录权限
```
grant all privileges on *.* to 'root'@'%' identified by '12345678';
flush privileges;
```
到这里MySQL就配置完成了。

##配置Hive的MySQL元数据库
在hive/conf目录中新增hive-site.xml文件并且插入以下内容
```
cp hive-default.xml.template hive-site.xml
```
```
<property>
    <name>javax.jdo.option.ConnectionDriverName</name>
    <value>com.mysql.jdbc.Driver</value>
    <description>Driver class name for a JDBC metastore</description>
</property>

<property>
    <name>javax.jdo.option.ConnectionURL</name>
    <value>jdbc:mysql://hadoop101:3306/hive?createDatabaseIfNotExist=true&amp;useSSL=false</value>
    <description>JDBC connect string for a JDBC metastore</description>
</property>

<property>
    <name>javax.jdo.option.ConnectionUserName</name>
    <value>root</value>
    <description>Username to use against metastore database</description>
</property>
<property>
    <name>javax.jdo.option.ConnectionPassword</name>
    <value>123456</value>
    <description>password to use against metastore database</description>
</property>
```
###下载mysql-connector-java
在 https://dev.mysql.com/downloads/connector/j/5.1.html 中下载mysql-connector-java，并且把该文件拉到../hive/lib目录中
###初始化元数据库
```
schematool -dbType mysql -initSchema
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302230835.png)
在这里遇到一个比较坑的就是官方文档是在hive/bin目录执行上面的命令的，但我在执行这条命令之后就遇到这个报错：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302231100.png)
卡了好久，切换到hive/conf目录再执行这条命令居然成功了- - ，不知道是不是一个bug
## 启动Hive
在启动hive之前需要先启动hadoop的dfs
###启动dfs

切换到hadoop的sbin目录
```
./start-dfs.sh
```
### 启动Hive
```
hive
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302231259.png)
一个简单的测试：
```
show databases;
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190302231340.png)

##Hive 常见属性配置
### Hive 数据仓库位置配置
* Default 数据仓库的最原始位置是在 hdfs 上的：/user/hive/warehouse 路径下
* 在仓库目录下，没有对默认的数据库 default 创建文件夹。如果某张表属于 default数据库，直接在数据仓库目录下创建一个文件夹。
* 修改 default 数据仓库原始位置（将 hive-default.xml.template 如下配置信息拷贝到hive-site.xml 文件中）
```
<property>
<name>hive.metastore.warehouse.dir</name>
<value>/user/hive/warehouse</value>
<description>location of default database for the warehouse</description>
</property>
```

### 查询后信息显示配置
在 hive-site.xml 文件中添加如下配置信息，就可以实现显示当前数据库，以及查询表的头信息配置。
```
<property>
<name>hive.cli.print.header</name>
<value>true</value>
</property>
<property>
<name>hive.cli.print.current.db</name>
<value>true</value>
</property>
```
重新启动 hive，对比配置前后差异
* 配置前：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190319143023.png)

* 配置后：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190319143119.png)

### Hive 运行日志信息配置
Hive 的 log 默认存放在/tmp/atguigu/hive.log 目录下（当前用户名下）
修改 hive 的 log 存放日志到/opt/module/hive/logs
* 修改/opt/module/hive/conf/hive-log4j.properties.template 文件名称为hive-log4j.properties
* 在 hive-log4j.properties 文件中修改 log 存放位置
```
hive.log.dir=/opt/module/hive/logs
```

到这里，Hive的安装配置就完成啦！
<hr />