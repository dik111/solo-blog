title: 大数据入门09-HDFS总结
date: '2019-01-15 02:11:16'
updated: '2019-11-10 21:57:07'
tags: [HDFS, 大数据]
permalink: /articles/2019/01/15/1573384294325.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

## HDFS概述

HDFS（Hadoop Distributed File System），它是一个文件系统，用于存储文件，通过目录树来定位文件；其次，它是分布式的，由很多服务器联合起来实现其功能，集群中的服务器有各自的角色。
HDFS的使用场景：适合一次写入，多次读出的场景，且不支持文件的修改。适合用来做数据分析，并不适合用来做网盘应用。

### HDFS优缺点
#### 优点
* 高容错性
1)数据自动保存多个副本。它通过增加副本的形式，提高容错性
2)某一个副本丢失以后，它可以自动恢复

* 适合处理大数据
1)数据规模：能够处理数据规模达到GB、TB、甚至PB级别的数据
2)文件规模：能够处理百万规模以上的文件数量，数量相当之大

* 可构建在廉价机器上，通过多副本机制，提高可靠性

#### 缺点

* 不适合低延时数据访问，比如毫秒级的存储数据，是做不到的

* 无法高效的对大量小文件进行存储
1)存储大量小文件的话，它会占用NameNode大量的内存来存储文件目录和块信息。这样是不可取的，因为NameNode的内存总是有限的
2)小文件存储的寻址时间会超过读取时间，它违反了HDFS的设计目标

* 不支持并发写入、文件随机修改
1)一个文件只能有一个写，不允许多个线程同时写
2)仅支持数据append（追加），不支持文件的随机修改

###HDFS组成架构
1) NameNode（nn）：就是Master，它是一个主管、管理者。
* 管理HDFS的名称空间
* 配置副本策略
* 管理数据块（Block）映射信息
* 处理客户端读写请求

2) DataNode：就是Slave。NameNode下达命令，DataNode执行实际的操作
* 存储实际的数据块
* 执行数据块的读/写操作

3) Client：就是客户端
* 文件切分。文件上传HDFS的时候，Client将文件切分成一个一个的Block，然后进行上传
* 与NameNode交互，获取文件的位置信息
* 与DataNode交互，读取或者写入数据
* Client提供一些命令来管理HDFS，比如NameNode格式化
* Client可以通过一些命令来访问HDFS，比如对HDFS增删查改操作

4) Secondary NameNode：并非NameNode的热备。当NameNode挂掉的时候，它并不能马上替换NameNode并提供服务
* 辅助NameNode，分担其工作量，比如定期合并Fsimage和Edits，并推送给NameNode 
* 在紧急情况下，可辅助恢复NameNode

## HDFS的常用Shell操作

### 基本语法
bin/hadoop fs 具体命令   OR  bin/hdfs dfs 具体命令
dfs是fs的实现类

### 命令大全
```
[-appendToFile <localsrc> ... <dst>]
        [-cat [-ignoreCrc] <src> ...]
        [-checksum <src> ...]
        [-chgrp [-R] GROUP PATH...]
        [-chmod [-R] <MODE[,MODE]... | OCTALMODE> PATH...]
        [-chown [-R] [OWNER][:[GROUP]] PATH...]
        [-copyFromLocal [-f] [-p] <localsrc> ... <dst>]
        [-copyToLocal [-p] [-ignoreCrc] [-crc] <src> ... <localdst>]
        [-count [-q] <path> ...]
        [-cp [-f] [-p] <src> ... <dst>]
        [-createSnapshot <snapshotDir> [<snapshotName>]]
        [-deleteSnapshot <snapshotDir> <snapshotName>]
        [-df [-h] [<path> ...]]
        [-du [-s] [-h] <path> ...]
        [-expunge]
        [-get [-p] [-ignoreCrc] [-crc] <src> ... <localdst>]
        [-getfacl [-R] <path>]
        [-getmerge [-nl] <src> <localdst>]
        [-help [cmd ...]]
        [-ls [-d] [-h] [-R] [<path> ...]]
        [-mkdir [-p] <path> ...]
        [-moveFromLocal <localsrc> ... <dst>]
        [-moveToLocal <src> <localdst>]
        [-mv <src> ... <dst>]
        [-put [-f] [-p] <localsrc> ... <dst>]
        [-renameSnapshot <snapshotDir> <oldName> <newName>]
        [-rm [-f] [-r|-R] [-skipTrash] <src> ...]
        [-rmdir [--ignore-fail-on-non-empty] <dir> ...]
        [-setfacl [-R] [{-b|-k} {-m|-x <acl_spec>} <path>]|[--set <acl_spec> <path>]]
        [-setrep [-R] [-w] <rep> <path> ...]
        [-stat [format] <path> ...]
        [-tail [-f] <file>]
        [-test -[defsz] <path>]
        [-text [-ignoreCrc] <src> ...]
        [-touchz <path> ...]
        [-usage [cmd ...]]
```

### 常用命令实操
* -help：输出这个命令参数
```
hadoop fs -help rm
```
```
-rm [-f] [-r|-R] [-skipTrash] <src> ... :
  Delete all files that match the specified file pattern. Equivalent to the Unix
  command "rm <src>"
                                                                                 
  -skipTrash  option bypasses trash, if enabled, and immediately deletes <src>   
  -f          If the file does not exist, do not display a diagnostic message or 
              modify the exit status to reflect an error.                        
  -[rR]       Recursively deletes directories  
  ```

* -ls: 显示目录信息
```
hadoop fs -ls /
```
```
Found 5 items
-rw-r--r--   3 root supergroup       1366 2019-02-15 15:33 /README.txt
drwxr-xr-x   - root supergroup          0 2019-02-21 14:20 /directory
drwxr-xr-x   - root supergroup          0 2019-02-18 10:09 /hadoop
drwxrwxr-x   - root supergroup          0 2019-02-20 16:24 /tmp
drwxr-xr-x   - root supergroup          0 2019-02-27 11:48 /user
```
* -mkdir：在HDFS上创建目录
```
hadoop fs -mkdir -p /sanguo/shuguo
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416174323.png)

* -moveFromLocal：从本地剪切粘贴到HDFS
```
touch kongming.txt
hadoop fs -moveFromLocal ./kongming.txt /sanguo/shuguo
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416174603.png)

* -appendToFile：追加一个文件到已经存在的文件末尾
```
touch liubei.txt
vim liubei.txt
hadoop fs -appendToFile liubei.txt /sanguo/shuguo/kongming.txt
```
* -cat：显示文件内容
```
hadoop fs -cat /sanguo/shuguo/kongming.txt
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416175122.png)

* -chgrp 、-chmod、-chown：Linux文件系统中的用法一样，修改文件所属权限
```
hadoop fs  -chmod  666  /sanguo/shuguo/kongming.txt
hadoop fs  -chown  atguigu:atguigu   /sanguo/shuguo/kongming.txt
```

* -copyFromLocal：从本地文件系统中拷贝文件到HDFS路径去
```
hadoop fs -copyFromLocal NOTICE.txt /
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416175646.png)

* -copyToLocal：从HDFS拷贝到本地
```
hadoop fs -copyToLocal /sanguo/shuguo/kongming.txt ./
```

* -cp ：从HDFS的一个路径拷贝到HDFS的另一个路径
```
hadoop fs -cp /sanguo/shuguo/kongming.txt /zhuge.txt
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416181455.png)

* -mv：在HDFS目录中移动文件
```
hadoop fs -mv /zhuge.txt /sanguo/shuguo/
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416181749.png)

* -getmerge：合并下载多个文件，比如HDFS的目录 /user/atguigu/test下有多个文件:log.1, log.2,log.3,...

```
hadoop fs -getmerge /sanguo/shuguo/* ./zaiyiqi.txt
```

* -get：等同于copyToLocal，就是从HDFS下载文件到本地
```
hadoop fs -get /sanguo/shuguo/kongming.txt ./
```

* -put：等同于copyFromLocal

```
hadoop fs -put ./zaiyiqi.txt /user/
```

* -rm：删除文件或文件夹
```
hadoop fs -rm /user/zaiyiqi.txt
```

* -du统计文件夹的大小信息
```
hadoop fs -du -s -h /user
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190416182500.png)

## HDFS的数据流
### HDFS写数据流程
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190417152653.png)

* 客户端通过Distributed FileSystem模块向NameNode请求上传文件，NameNode检查目标文件是否已存在，父目录是否存在
* NameNode返回是否可以上传
* 客户端请求第一个 Block上传到哪几个DataNode服务器上
* NameNode返回3个DataNode节点，分别为dn1,dn2,dn3
* 客户端通过FSDataOutputStream模块请求dn1上传数据，dn1收到请求会继续调用dn2，然后dn2调用dn3，将这个通信管道建立完成
* dn1、dn2、dn3逐级应答客户端
* 客户端开始往dn1上传第一个Block（先从磁盘读取数据放到一个本地内存缓存），以Packet为单位，dn1收到一个Packet就会传给dn2，dn2传给dn3；dn1每传一个packet会放入一个应答队列等待应答
* 当一个Block传输完成之后，客户端再次请求NameNode上传第二个Block的服务器。（重复执行3-7步）

### HDFS读数据流程
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190423163351.png)
* 客户端通过Distributed FileSystem向NameNode请求下载文件，NameNode通过查询元数据，找到文件块所在的DataNode地址
* 挑选一台DataNode（就近原则，然后随机）服务器，请求读取数据
* DataNode开始传输数据给客户端（从磁盘里面读取数据输入流，以Packet为单位来做校验）
* 客户端以Packet为单位接收，先在本地缓存，然后写入目标文件

##SecondaryNameNode和NameNode

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190423173551.png)

###第一阶段：NameNode启动
* 第一次启动NameNode格式化后，创建Fsimage和Edits文件。如果不是第一次启动，直接加载编辑日志和镜像文件到内存
* 客户端对元数据进行增删改的请求
* NameNode记录操作日志，更新滚动日志
* NameNode在内存中对数据进行增删改

### 第二阶段：Secondary NameNode工作
* Secondary NameNode询问NameNode是否需要CheckPoint。直接带回NameNode是否检查结果
* Secondary NameNode请求执行CheckPoint
* NameNode滚动正在写的Edits日志
* 将滚动前的编辑日志和镜像文件拷贝到Secondary NameNode
* Secondary NameNode加载编辑日志和镜像文件到内存，并合并
* 生成新的镜像文件fsimage.chkpoint
* 拷贝fsimage.chkpoint到NameNode
* NameNode将fsimage.chkpoint重新命名成fsimage

## DataNode

### DataNode工作机制
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190423181910.png)

* 一个数据块在DataNode上以文件形式存储在磁盘上，包括两个文件，一个是数据本身，一个是元数据包括数据块的长度，块数据的校验和，以及时间戳
* DataNode启动后向NameNode注册，通过后，周期性（1小时）的向NameNode上报所有的块信息
* 心跳是每3秒一次，心跳返回结果带有NameNode给该DataNode的命令如复制块数据到另一台机器，或删除某个数据块。如果超过10分钟没有收到某个DataNode的心跳，则认为该节点不可用
* 集群运行中可以安全加入和退出一些机器
<hr />
