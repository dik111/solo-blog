title: 大数据入门03-Hadoop完全分布式运行模式
date: '2018-12-19 00:13:37'
updated: '2018-12-19 00:13:37'
tags: [hadoop, 大数据]
permalink: /articles/2018/12/19/1573384294719.html
---
<p class="description"></p>

<img src="https://" alt="" style="width:100%" />

<!-- more -->

## 虚拟机准备
修改克隆主机的IP地址以及名字
* 我们打开克隆的3台centos7虚拟机，修改里面对应的IP地址为105,106，107
```
vim /etc/sysconfig/network-scripts/ifcfg-eth0
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162411.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162449.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162509.png)

* 修改MAC地址
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190217133024.png)
在配置IP地址的文件中添加：
```
MACADDR=XXXXXXXXXXXXXXXX
```
* 修改主机的名字，分别为105,106,107
```
vim /etc/sysconfig/network
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162841.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162858.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204162911.png)

* 修改hosts配置文件，添加对应的105，106，107的IP地址
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204170226.png)

* 为三台虚拟机配置ssh
分别在105，106，107上面创建ssh
```
ssh-keygen -t rsa
```
然后敲（三个回车），就会生成两个文件id_rsa（私钥）、id_rsa.pub（公钥）
进入到.ssh文件夹，将产生的公钥拷贝到目标机器上
```
ssh-copy-id hadoop105
ssh-copy-id hadoop106
ssh-copy-id hadoop107
```
* 编写xsync集群分发脚本
在~/bin目录在创建xsync创建文件，文件内容如下：
```
touch xsync
vim xsync
```
```
#!/bin/bash
#1 获取输入参数个数，如果没有参数，直接退出
pcount=$#
if((pcount==0)); then
echo no args;
exit;
fi

#2 获取文件名称
p1=$1
fname=`basename $p1`
echo fname=$fname

#3 获取上级目录到绝对路径
pdir=`cd -P $(dirname $p1); pwd`
echo pdir=$pdir

#4 获取当前用户名称
user=`whoami`

#5 循环
for((host=103; host<105; host++)); do
        echo ------------------- hadoop$host --------------
        rsync -rvl $pdir/$fname $user@hadoop$host:$pdir
done

```
其中#5 循环部分可以改成对应的主机名称
修改脚本 xsync 具有执行权限
```
chmod 777 xsync
```
## 集群配置
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204212905.png)

* 核心配置文件
配置core-site.xml
```
[root@hadoop105 ~]# cd /opt/module/hadoop-2.7.7/etc/hadoop/
[root@hadoop105 hadoop]# vim core-site.xml
```
把namenode节点改成105

![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204213451.png)

* HDFS配置文件

配置hadoop-env.sh

```
[root@hadoop105 hadoop]# vim hadoop-env.sh
export JAVA_HOME=/opt/module/jdk-11.0.1
```

配置hdfs-site.xml
```
[root@hadoop105 hadoop]# vim hdfs-site.xml
```
在该文件中编写如下配置
```
<!-- 指定Hadoop辅助名称节点主机配置 -->
<property>
      <name>dfs.namenode.secondary.http-address</name>
      <value>hadoop107:50090</value>
</property>
```
* YARN配置文件
配置yarn-env.sh  
```
[root@hadoop105 hadoop]# vim yarn-env.sh
export JAVA_HOME=/opt/module/jdk-11.0.1
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204215103.png)
配置yarn-site.xml
```
<!-- Reducer获取数据的方式 -->
<property>
		<name>yarn.nodemanager.aux-services</name>
		<value>mapreduce_shuffle</value>
</property>

<!-- 指定YARN的ResourceManager的地址 -->
<property>
		<name>yarn.resourcemanager.hostname</name>
		<value>hadoop106</value>
</property>

```
* MapReduce配置文件
配置mapred-env.sh
```
[root@hadoop105 hadoop]# vim mapred-env.sh
export JAVA_HOME=/opt/module/jdk-11.0.1
```
配置mapred-site.xml
```
[root@hadoop105 hadoop]# cp mapred-site.xml.template mapred-site.xml
[root@hadoop105 hadoop]# vim mapred-site.xml

<!-- 指定MR运行在Yarn上 -->
<property>
		<name>mapreduce.framework.name</name>
		<value>yarn</value>
</property>

```
接着用xsync脚本把编写的文件同步到106,107
```
xsync /opt/module/hadoop-2.7.7/etc/hadoop/
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204221353.png)

##群起集群
* 格式化NameNode
格式化之前，一定要先停止上次启动的所有namenode和datanode进程，然后再分别在105,106,107上删除data和log数据
```
rm -rf data/ logs/
bin/hdfs namenode -format
```
* 配置slaves
```
[root@hadoop105 hadoop-2.7.7]# vim etc/hadoop/slaves
hadoop105
hadoop106
hadoop107
```
接着把它分发到106，107
```
~/bin/xsync /opt/module/hadoop-2.7.7/etc/hadoop/slaves
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204223134.png)

* 启动HDFS
在hadoop105上启动：
```
sbin/start-dfs.sh
#sbin/stop-dfs.sh (关闭)
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204223740.png)
分别在105，106，107上面用jps命令查看是否启动正确：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204223834.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204223854.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204223908.png)

* 启动YARN
在hadoop106上启动：
```
sbin/start-yarn.sh 
#sbin/stop-yarn.sh (关闭)
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204224224.png)
启动之后再在105，106，107上面用jps命令查看是否启动正确：
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204224259.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204224320.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204224334.png)
最后我们登录 http://hadoop105:50070/explorer.html#/
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204224454.png)
如果能成功打开，那么我们完全分布式集群就搭建成功了！

## 集群基本测试
我们上传一个小文件到集群上面用作测试:
```
bin/hdfs dfs -put README.txt /
```
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204225130.png)
![](https://dik111-1258101294.cos.ap-guangzhou.myqcloud.com/20190204225221.png)
<hr />